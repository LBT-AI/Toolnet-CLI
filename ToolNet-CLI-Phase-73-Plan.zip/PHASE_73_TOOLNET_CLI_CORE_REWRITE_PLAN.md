# TOOLNET CLI — PHASE 73 CORE REWRITE PLAN
## OpenCode-style Core + Antigravity-style Shared Agent Architecture

**Status:** Proposed  
**Priority:** P0 / Core Architecture  
**Repository:** `LBT-AI/Toolnet-CLI`  
**Primary objective:** Biến ToolNet CLI thành coding agent thực sự có thể đọc code, sửa file, chạy lệnh, đọc lỗi, tự sửa và xác minh kết quả bằng một execution path duy nhất.

---

# 1. MỤC TIÊU

ToolNet CLI phải hoạt động như một coding agent thực thụ, không phải chatbot sinh code.

Chu trình chuẩn:

```text
USER REQUEST
    ↓
UNDERSTAND TASK
    ↓
GATHER CONTEXT
    ↓
SEARCH / READ
    ↓
DECIDE
    ↓
TOOL CALL
    ↓
PERMISSION
    ↓
EXECUTE
    ↓
TOOL RESULT
    ↓
VERIFY
    ↓
TEST
    ↓
REPAIR IF NEEDED
    ↓
FINAL ANSWER
```

Một task chỉ được coi là hoàn thành khi các side effect cần thiết đã thật sự xảy ra và được kiểm chứng.

Ví dụ:

```text
User:
"Tạo app.py, chạy thử, nếu lỗi thì tự sửa cho tới khi chạy được."

Agent:
read/list context
→ write_file(app.py)
→ verify file exists
→ shell("python3 app.py")
→ observe stderr
→ edit/apply_patch
→ shell("python3 app.py")
→ exitCode=0
→ final answer
```

Không được coi code block là execution:

```bash
cat > app.py <<'EOF'
...
EOF
python3 app.py
```

Nếu model chỉ in block trên nhưng tool chưa chạy thì task phải được đánh dấu **chưa hoàn thành**.

---

# 2. HƯỚNG KIẾN TRÚC

ToolNet sẽ không clone nguyên OpenCode hoặc Antigravity.

## 2.1. Học từ OpenCode

Dùng OpenCode làm chuẩn kỹ thuật cho:

- Tool Registry.
- LLM runtime.
- Provider/protocol normalization.
- Structured tool lifecycle.
- Session Processor.
- Tool call state.
- Snapshot/diff.
- Error propagation.
- Tool result replay.
- Context compaction.
- Doom-loop detection.
- Permission integration.
- Testability của agent runtime.

## 2.2. Học từ Antigravity

Dùng Antigravity làm chuẩn sản phẩm/kiến trúc cấp cao cho:

- Một Shared Agent Engine duy nhất.
- TUI / headless / subagent cùng dùng chung core.
- Scoped tools theo agent.
- Background task.
- Async subagents.
- Permission UX rõ ràng.
- Persistent history.
- Hooks.
- MCP integration.
- Remote/SSH-first experience.

## 2.3. Giữ lợi thế riêng của ToolNet

Giữ và tích hợp lại:

- ToolNet API.
- Multi-provider/model routing.
- Free model/provider ecosystem.
- ToolNet Memory.
- Skills.
- Browser/Web tools.
- Teamwork.
- Plugins.
- TUI riêng.
- Usage tracking.
- Provider picker.
- Session UI.
- Reasoning UI.

---

# 3. NGUYÊN TẮC BẮT BUỘC

## 3.1. ONE EXECUTION PATH

Toàn bộ hệ thống phải dùng đúng một đường execution:

```text
TUI
Simple REPL
Headless
Subagent
Teamwork
    ↓
Shared Agent Core
    ↓
SessionProcessor
    ↓
LLM Runtime
    ↓
Tool Registry
    ↓
Permission
    ↓
Tool Executor
    ↓
Verify
    ↓
Tool Result
    ↓
LLM Runtime
```

Không được tồn tại agent loop riêng trong TUI.

Không được để:

```text
agentWiring.ts
→ provider.stream()
→ tự parse tool_calls
→ tự ToolGateway.execute()
```

song song với:

```text
AgentRuntime
→ AgentHarness
→ ModelAdapter
→ tool loop
```

## 3.2. TUI CHỈ LÀ VIEW

TUI chỉ subscribe và render event.

TUI không được:

- Parse provider tool calls.
- Execute tool.
- Evaluate permission.
- Tự duy trì ReAct loop.
- Quyết định khi nào task hoàn thành.
- Tự ghép provider-specific streaming chunks.

TUI chỉ biết event chuẩn hóa.

## 3.3. SIDE-EFFECT TRUTHFULNESS

Không được nói:

- "Đã tạo file".
- "Đã sửa".
- "Đã chạy".
- "Test pass".
- "Build thành công".
- "Deploy xong".

nếu chưa có tool result xác minh.

## 3.4. MODEL-INDEPENDENT CORE

Core không phụ thuộc OpenAI-format trực tiếp.

Mọi provider phải đi qua protocol adapter và trả cùng một event contract.

## 3.5. GUARD CLAUSES / EARLY RETURN

Code mới:

- Ưu tiên guard clauses.
- Tránh nested `if/else` không cần thiết.
- Module nhỏ.
- Single responsibility.
- Không duplicate execution logic.

---

# 4. KIẾN TRÚC ĐÍCH

```text
┌─────────────────────────────────────────────┐
│                 TOOLNET UI                  │
│                                             │
│  TUI │ Simple REPL │ Headless │ API │ Agent │
└──────────────────────┬──────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────┐
│             SHARED AGENT ENGINE             │
│                                             │
│  Task State                                 │
│  Session                                    │
│  Completion Gate                            │
│  Event Bus                                  │
└──────────────────────┬──────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────┐
│             SESSION PROCESSOR               │
│                                             │
│ pending → running → completed/error         │
│ snapshot / usage / retry / cancellation     │
└──────────────────────┬──────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────┐
│                 LLM RUNTIME                 │
│                                             │
│ OpenAI │ Gemini │ Anthropic │ ToolNet │ ... │
└──────────────────────┬──────────────────────┘
                       │
                normalized events
                       │
                       ▼
┌─────────────────────────────────────────────┐
│               TOOL REGISTRY                 │
│                                             │
│ schema + execute + risk + verify + metadata │
└──────────────────────┬──────────────────────┘
                       │
                       ▼
               Permission Engine
                       │
                       ▼
                 Tool Executor
                       │
                       ▼
                    Verify
                       │
                       ▼
                  Tool Result
                       │
                       └───────────→ LLM
```

---

# 5. CẤU TRÚC THƯ MỤC ĐỀ XUẤT

```text
src/
├── core/
│   ├── agent/
│   │   ├── engine.ts
│   │   ├── session.ts
│   │   ├── processor.ts
│   │   ├── events.ts
│   │   ├── taskState.ts
│   │   ├── completionGate.ts
│   │   ├── retry.ts
│   │   └── cancellation.ts
│   │
│   ├── llm/
│   │   ├── runtime.ts
│   │   ├── request.ts
│   │   ├── response.ts
│   │   ├── capabilities.ts
│   │   ├── toolStream.ts
│   │   └── protocols/
│   │       ├── openai.ts
│   │       ├── toolnet.ts
│   │       ├── gemini.ts
│   │       ├── anthropic.ts
│   │       └── structured.ts
│   │
│   ├── tools/
│   │   ├── registry.ts
│   │   ├── tool.ts
│   │   ├── executor.ts
│   │   ├── result.ts
│   │   ├── read.ts
│   │   ├── write.ts
│   │   ├── edit.ts
│   │   ├── patch.ts
│   │   ├── shell.ts
│   │   ├── grep.ts
│   │   ├── glob.ts
│   │   ├── webFetch.ts
│   │   ├── question.ts
│   │   └── task.ts
│   │
│   ├── permission/
│   │   ├── engine.ts
│   │   ├── policy.ts
│   │   ├── resource.ts
│   │   └── sessionTrust.ts
│   │
│   ├── workspace/
│   │   ├── context.ts
│   │   ├── snapshot.ts
│   │   ├── diff.ts
│   │   ├── filesystem.ts
│   │   └── projectDetector.ts
│   │
│   └── agents/
│       ├── manager.ts
│       ├── subagent.ts
│       ├── background.ts
│       └── roles.ts
│
├── tui/
│   └── ...
│
├── providers/
│   └── ...
│
└── simple-repl.ts
```

Không bắt buộc rename toàn bộ ngay ở Phase 1. Có thể migrate dần nhưng architecture đích phải là cấu trúc trên.

---

# 6. EVENT CONTRACT

Toàn bộ UI và integrations phải dùng event chuẩn.

```ts
type AgentEvent =
  | { type: "agent-start"; sessionId: string }
  | { type: "thinking-start" }
  | { type: "reasoning-delta"; text: string }
  | { type: "tool-input-start"; callId: string; name: string }
  | { type: "tool-input-delta"; callId: string; delta: string }
  | { type: "tool-call"; callId: string; name: string; input: unknown }
  | { type: "permission-required"; callId: string; resource: string }
  | { type: "tool-running"; callId: string }
  | { type: "tool-result"; callId: string; result: ToolResult }
  | { type: "tool-error"; callId: string; error: string }
  | { type: "verification-start"; callId: string }
  | { type: "verification-result"; callId: string; ok: boolean }
  | { type: "text-delta"; text: string }
  | { type: "step-finish" }
  | { type: "agent-complete" }
  | { type: "cancelled" }
  | { type: "error"; error: string };
```

Provider-specific event không được lọt ra ngoài LLM adapter.

---

# 7. TOOL CALL STATE

Mỗi tool call phải có lifecycle:

```text
PENDING
   ↓
RUNNING
   ↓
COMPLETED
```

hoặc:

```text
PENDING
   ↓
RUNNING
   ↓
ERROR
```

Schema:

```ts
interface ToolCallState {
  callId: string;
  name: string;
  input: unknown;

  status:
    | "pending"
    | "running"
    | "completed"
    | "error"
    | "cancelled";

  startedAt?: number;
  endedAt?: number;

  output?: ToolResult;
  error?: string;

  permission?: PermissionDecision;
  verification?: VerificationResult;
}
```

---

# 8. TOOL RESULT CHUẨN

Không để mỗi tool tự trả một kiểu JSON khác nhau.

```ts
interface ToolResult {
  ok: boolean;

  stdout?: string;
  stderr?: string;
  exitCode?: number;

  data?: unknown;

  truncated?: boolean;
  outputPath?: string;

  metadata?: Record<string, unknown>;
}
```

Model luôn nhận tool result với đúng `tool_call_id`.

---

# 9. TOOL REGISTRY DUY NHẤT

Tool Registry phải là single source of truth.

Mỗi tool chứa:

```ts
interface ToolDefinition<I = unknown> {
  id: string;
  description: string;
  parameters: JsonSchema;

  risk: "read" | "write" | "execute" | "network";

  execute(
    input: I,
    ctx: ToolExecutionContext
  ): Promise<ToolResult>;

  verify?(
    input: I,
    result: ToolResult,
    ctx: ToolExecutionContext
  ): Promise<VerificationResult>;
}
```

Không được:

- Một schema ở `agentTools.ts`.
- Một schema khác ở TUI.
- Một execute handler khác trong ToolGateway.
- Một alias map khác trong ModelAdapter.

Tất cả phải derive từ Registry.

---

# 10. TOOL SET CANONICAL

Xóa alias thừa.

## Giữ

```text
read_file
write_file
edit_file
apply_patch
shell
grep
glob
web_fetch
question
task
skill
```

Có thể bổ sung sau:

```text
lsp
todo
browser
mcp
```

## Xóa/deprecate

```text
bash
run_command

grep_search
glob_search
```

Các alias cũ có thể giữ compatibility trong parser nội bộ trong một thời gian nhưng không expose cho model.

---

# 11. MODEL-SPECIFIC TOOL EXPOSURE

Không đưa tất cả tool cho mọi model.

Ví dụ:

```text
GPT-style coding model:
read_file
apply_patch
shell
grep
glob
```

Model khác:

```text
read_file
write_file
edit_file
shell
grep
glob
```

Research agent:

```text
read_file
grep
glob
web_fetch
```

Tester:

```text
read_file
shell
grep
```

Subagent chỉ nhận tool scope parent cấp.

---

# 12. MODEL CAPABILITIES

Thay capability boolean mơ hồ bằng contract rõ hơn.

```ts
interface ModelCapabilities {
  reasoning: boolean;
  reasoningStream: boolean;
  reasoningEffort: boolean;

  toolCalling:
    | "native"
    | "structured"
    | "none";

  streaming: boolean;
  vision: boolean;
}
```

## Quy tắc

### Native

Provider trả native function/tool calls.

```text
toolCalling = native
```

### Structured fallback

Model không có native tool calling nhưng có thể tuân thủ JSON action protocol.

```text
toolCalling = structured
```

### None

Model thực sự không có khả năng tool use.

```text
toolCalling = none
```

Core không được đoán capability dựa vào substring model ID.

---

# 13. FIX TOOLNET PROVIDER CAPABILITIES

ToolNet provider phải propagate đầy đủ:

```text
reasoning
reasoningStream
reasoningEffort
toolCalling
streaming
vision
```

Không được làm mất:

```text
tools
nativeToolCalls
```

như implementation hiện tại.

Đặc biệt cần test:

```text
alims-intl.llm
```

Nếu model không hỗ trợ native OpenAI `tool_calls`, phải được map sang:

```text
toolCalling = structured
```

nếu gateway/model hỗ trợ structured action protocol.

---

# 14. LLM PROTOCOL NORMALIZATION

Core chỉ hiểu:

```text
reasoning
tool-call
tool-result
text
finish
error
```

Adapter chịu trách nhiệm dịch provider format.

## OpenAI

```text
delta.tool_calls
finish_reason
reasoning_content
```

→ normalized events.

## Gemini

```text
functionCall
functionResponse
```

→ normalized events.

## Anthropic

```text
tool_use
tool_result
thinking
```

→ normalized events.

## ToolNet

Gateway-specific response phải được normalize trước khi vào SessionProcessor.

---

# 15. STRUCTURED TOOL FALLBACK

Model không có native tool calling không được phép chỉ in bash block.

Structured protocol:

```json
{
  "type": "tool_call",
  "tool": "shell",
  "arguments": {
    "command": "python3 app.py"
  }
}
```

Hoặc multi-call:

```json
[
  {
    "type": "tool_call",
    "tool": "read_file",
    "arguments": {
      "path": "app.py"
    }
  },
  {
    "type": "tool_call",
    "tool": "shell",
    "arguments": {
      "command": "python3 app.py"
    }
  }
]
```

Parser:

- Strict JSON only.
- Whitelist tool IDs.
- Validate JSON Schema.
- Không execute markdown code block.
- Không execute text tự do.
- Không regex bash block rồi chạy.

---

# 16. SHARED AGENT ENGINE

Entry point duy nhất:

```ts
const result = await agentEngine.run({
  sessionId,
  prompt,
  model,
  cwd,
  workspaceRoot,
  mode,
  signal,
});
```

Mọi interface phải gọi function này.

## TUI

```text
agentEngine.run()
→ subscribe events
→ render
```

## Simple REPL

```text
agentEngine.run()
→ print events/result
```

## Headless

```text
agentEngine.run()
→ JSON output
```

## Subagent

```text
agentEngine.run({
  parentSessionId,
  scopedTools,
  scopedPermission
})
```

---

# 17. SESSION PROCESSOR

SessionProcessor chịu trách nhiệm:

- Tool call state.
- Reasoning state.
- Text state.
- Tool settlement.
- Retry.
- Cancellation.
- Snapshot.
- Usage.
- Completion state.
- Context compaction.
- Doom-loop detection.
- Persist session history.

Pseudo-flow:

```ts
while (!done) {
  const response = await llm.stream(...);

  for await (const event of response) {
    await processor.handle(event);
  }

  if (processor.requiresCompaction()) {
    await compact();
    continue;
  }

  if (processor.shouldStop()) {
    break;
  }

  if (processor.requiresAnotherTurn()) {
    continue;
  }

  done = true;
}
```

---

# 18. SNAPSHOT + DIFF

Trước mutation:

```text
snapshotBefore
```

Sau mutation:

```text
snapshotAfter
```

Sau step:

```text
diff(snapshotBefore, snapshotAfter)
```

Không được verify edit bằng cách lấy hash "before" sau khi file đã được sửa.

## File mutation verification

### write_file

PASS nếu:

- file tồn tại.
- nội dung/hash đúng với output mong đợi.

### edit_file

PASS nếu:

- file tồn tại.
- hash trước != hash sau.
- old string đã được xử lý đúng.
- new string xuất hiện khi phù hợp.

### apply_patch

PASS nếu:

- patch apply thành công.
- target files thay đổi.
- không có partial silent failure.

---

# 19. COMPLETION GATE

Final answer không chỉ dựa vào việc model không gọi tool nữa.

Task parser xác định requirement.

```ts
interface TaskRequirement {
  mutationRequired: boolean;
  executionRequired: boolean;
  verificationRequired: boolean;
  testRequired: boolean;
}
```

Completion Gate:

```ts
if (task.mutationRequired && successfulMutations === 0) {
  return "continue";
}

if (task.executionRequired && successfulExecutions === 0) {
  return "continue";
}

if (task.verificationRequired && !verificationPassed) {
  return "continue";
}

if (task.testRequired && !testsPassed) {
  return "continue";
}

return "complete";
```

Nếu model trả text nhưng task chưa complete:

```text
inject corrective instruction
→ continue agent loop
```

Không được final success.

---

# 20. CLAIM GUARD

Claim Guard vẫn được giữ nhưng chuyển xuống core.

Ví dụ phát hiện:

```text
"I created..."
"Đã tạo..."
"Đã sửa..."
"Tests pass..."
"Build succeeded..."
```

Nếu session state không có corresponding successful tool result:

```text
reject final
→ send corrective turn to model
```

Claim Guard chỉ là lớp cuối.

Completion Gate mới là lớp chính.

---

# 21. PERMISSION MODEL

Permission theo resource.

Ví dụ:

```text
read_file:/workspace/**
write_file:/workspace/**
shell:npm test
shell:git status
network:https://github.com/**
mcp:github/search
```

Decision:

```text
DENY
ASK
ALLOW
```

Ưu tiên:

```text
DENY > ASK > ALLOW
```

Không để tool executor tự mở readline/modal.

Flow:

```text
tool-call
→ permission.evaluate()
→ ALLOW
    → execute

→ ASK
    → emit permission-required
    → UI asks user
    → resume

→ DENY
    → tool-error
```

---

# 22. SECURITY

Bắt buộc giữ:

- Workspace boundary.
- Path traversal guard.
- Symlink handling.
- Shell timeout.
- Process tree cancellation.
- Output limit.
- Network permission.
- Secret redaction.
- Dangerous command classification.
- Session-scoped approval.
- Explicit full-access mode.

Không cho model tự quyết định security mode.

---

# 23. SHELL EXECUTION

Shell result phải chuẩn:

```json
{
  "ok": true,
  "stdout": "...",
  "stderr": "",
  "exitCode": 0
}
```

Các requirement:

- `cwd` rõ ràng.
- timeout.
- AbortSignal.
- kill process tree.
- stdout/stderr riêng.
- exit code.
- truncate output có kiểm soát.
- preserve full output vào temp/log file khi quá dài.

Model cần nhận stderr đầy đủ vừa đủ để sửa lỗi.

---

# 24. CONTEXT GATHERING

Coding task phải ưu tiên context thật.

Agent cần:

```text
get workspace context
→ project detector
→ relevant files
→ grep/glob
→ targeted read
```

Không đọc toàn repo nếu không cần.

Không đoán:

- language.
- framework.
- package manager.
- test command.
- build command.

Project detector phải lấy từ file thật:

```text
package.json
pyproject.toml
requirements.txt
go.mod
Cargo.toml
composer.json
pom.xml
...
```

---

# 25. MEMORY

ToolNet Memory không được nhúng thẳng toàn bộ vào system prompt.

Phân chia:

```text
Working Context
Session Memory
Project Memory
Long-term Memory
```

Chỉ inject phần liên quan task.

Memory không được override:

- user request hiện tại.
- permission.
- workspace truth.
- tool result truth.

---

# 26. PLAN MODE / BUILD MODE

## Plan Mode

Expose read-only tools:

```text
read_file
grep
glob
web_fetch
```

Không mutation trừ `save_plan`.

## Build Mode

Expose coding tools cần thiết.

Plan mode không được tự execute implementation.

Build mode không được bắt model lập plan dài trước khi làm task nhỏ.

---

# 27. SUBAGENTS

Chỉ triển khai sau khi main Agent Core ổn định.

Parent:

```text
creates subtask
→ selects agent role
→ selects scoped tool set
→ sets permission scope
→ launches subagent
```

Subagent không mặc định có full tools.

Role:

```text
CODER
RESEARCHER
TESTER
REVIEWER
ARCHITECT
GENERAL
```

Mỗi role có tool set riêng.

---

# 28. BACKGROUND TASKS

Sau Phase core:

```text
task:start
task:progress
task:complete
task:error
```

Background task không được polling vô hạn.

Cần:

- task ID.
- cancellation.
- progress state.
- persisted state.
- notification on completion.
- concurrency limits.

---

# 29. MCP

MCP tool phải đi qua cùng Tool Registry / Permission lifecycle.

Không tạo MCP execution path riêng.

```text
MCP definition
→ Registry adapter
→ permission
→ execute
→ normalized ToolResult
→ SessionProcessor
```

---

# 30. HOOKS

Triển khai sau core ổn định.

Hook examples:

```text
pre-tool
post-tool
pre-write
post-write
pre-shell
post-shell
agent-start
agent-end
```

Use cases:

```text
post-write
→ prettier / biome / ruff

post-edit
→ diagnostics

post-test
→ collect report
```

Hook failure phải có policy rõ:

```text
ignore
warn
block
```

---

# 31. OBSERVABILITY

Log tối thiểu:

```text
sessionId
turn
model
provider
toolCallId
toolName
duration
permission
exitCode
verification
tokens
error
```

Không log secrets.

Debug mode:

```bash
TOOLNET_DEBUG=1 toolnet
```

Có trace:

```text
User
→ LLM turn 1
→ tool call write_file
→ permission allow
→ execute
→ verify
→ result
→ LLM turn 2
→ shell
...
```

---

# 32. TOKEN / OUTPUT MANAGEMENT

Tool output dài:

- truncate trước khi gửi model.
- giữ output full trong file tạm/log khi cần.
- gửi model metadata:

```json
{
  "truncated": true,
  "fullOutputPath": "..."
}
```

Không nhét hàng chục nghìn dòng terminal vào context.

---

# 33. RETRY

Retry chỉ cho lỗi phù hợp:

```text
429
503
network timeout
transient provider errors
```

Không retry vô hạn:

```text
401
403
invalid tool args
permission denied
syntax error trong code
```

Syntax/runtime error phải trả cho model để tự sửa, không HTTP retry.

---

# 34. DOOM LOOP DETECTION

Detect repeated identical calls:

```text
same tool
same normalized args
same unresolved outcome
```

Threshold mặc định:

```text
3
```

Sau threshold:

- warn model.
- require changed strategy.
- nếu vẫn lặp → stop task với diagnostic.

---

# 35. CANCELLATION

`Ctrl+C`:

- cancel current LLM request.
- cancel running tool process tree.
- update tool call = cancelled.
- session vẫn sống.
- quay lại input prompt.

Không được `process.exit()` trừ explicit `/exit`.

---

# 36. MIGRATION STRATEGY

Không rewrite toàn repo trong một commit.

Dùng Strangler Migration.

## Step A

Tạo `src/core/*` mới.

## Step B

Bridge existing tools vào Registry mới.

## Step C

Simple REPL chuyển sang Shared Agent Engine.

## Step D

TUI chuyển sang Shared Agent Engine.

## Step E

Headless/Subagent chuyển sang Shared Agent Engine.

## Step F

Xóa legacy loops.

---

# 37. PHASE ROADMAP

## PHASE 73.1 — Unified Contracts

Tạo:

```text
AgentEvent
ToolDefinition
ToolResult
ToolCallState
ModelCapabilities
PermissionDecision
VerificationResult
```

Acceptance:

- Typecheck pass.
- Không thay UI behavior.
- Unit tests contract.

---

## PHASE 73.2 — Canonical Tool Registry

Migrate:

```text
read_file
write_file
edit_file
apply_patch
shell
grep
glob
web_fetch
```

Acceptance:

- Một registry duy nhất.
- Schema derive từ registry.
- Tool execute derive từ registry.
- Remove duplicated schema definitions.

---

## PHASE 73.3 — LLM Runtime + Protocol Layer

Implement:

```text
OpenAI adapter
ToolNet adapter
Structured adapter
normalized stream events
```

Acceptance:

- Native tool call test.
- Structured fallback test.
- Streaming fragmented tool arguments test.
- Multi-tool-call test.

---

## PHASE 73.4 — Session Processor

Implement:

```text
tool lifecycle
text lifecycle
reasoning lifecycle
retry
cancellation
doom loop
session state
```

Acceptance:

```text
tool-call
→ running
→ result
→ next model turn
```

verified end-to-end.

---

## PHASE 73.5 — Shared Agent Engine

Create one:

```ts
agentEngine.run()
```

Acceptance:

- simple-repl uses it.
- headless uses it.
- no duplicate loop in new paths.

---

## PHASE 73.6 — TUI Migration

Remove from TUI:

```text
provider.stream
delta.tool_calls parsing
ToolGateway.execute
executeToolBatch
manual continueAgentLoop
```

TUI only:

```text
subscribe
render
approval response
```

Acceptance:

- TUI and Simple REPL produce same tool behavior.

---

## PHASE 73.7 — Capability Fix

Implement:

```text
native
structured
none
```

Test model:

```text
alims-intl.llm
```

Acceptance:

- model cannot silently fall back to fake execution.
- task requiring tool use cannot finish as text-only success.

---

## PHASE 73.8 — Snapshot + Verification

Implement real before/after verification.

Acceptance:

- write verify.
- edit verify.
- patch verify.
- shell execution verify.
- git diff/snapshot consistency.

---

## PHASE 73.9 — Completion Gate

Implement task requirement tracking.

Acceptance:

Mutation request + no successful mutation:

```text
FAIL / CONTINUE
```

Execution request + no shell result:

```text
FAIL / CONTINUE
```

Test request + failing tests:

```text
REPAIR / CONTINUE
```

---

## PHASE 73.10 — Legacy Removal

Delete/deprecate:

- duplicate agent loops.
- duplicate tool schemas.
- duplicate execution routers.
- tool aliases exposed to model.
- old direct provider calls outside LLM runtime.

Acceptance:

Repository-wide search confirms one primary execution path.

---

# 38. PHASE 74 — CODING INTELLIGENCE

Chỉ bắt đầu sau Phase 73 PASS.

Implement:

```text
LSP
definitions
references
diagnostics
symbols
hover
type info
rename
```

Tool:

```text
lsp_definition
lsp_references
lsp_diagnostics
lsp_symbols
```

Model-specific exposure.

---

# 39. PHASE 75 — SUBAGENTS

Implement Antigravity-style scoped async subagents.

Acceptance:

- parent assigns role.
- parent scopes tools.
- separate session.
- cancellation.
- result returns to parent.
- max concurrency.

---

# 40. PHASE 76 — BACKGROUND / TEAMWORK

Implement:

```text
background task
DAG dependencies
parallel tasks
inbox
progress
result aggregation
```

Không để background task bypass Shared Agent Engine.

---

# 41. PHASE 77 — MCP / PLUGINS / HOOKS

Unified extension layer.

```text
MCP
Plugin tools
Skills
Hooks
```

Tất cả đi qua:

```text
Tool Registry
→ Permission
→ Executor
→ ToolResult
```

---

# 42. BẮT BUỘC TEST THEO LỚP

## Unit

Test:

- schemas.
- parser.
- capabilities.
- permission.
- tool executor.
- tool result.
- verification.
- completion gate.
- loop detector.
- cancellation.

## Integration

Mock provider:

```text
assistant tool_call
→ executor
→ tool result
→ assistant final
```

## E2E

Real temp workspace.

---

# 43. GOLDEN E2E TEST 1 — CREATE FILE

Prompt:

```text
Tạo file toolnet-proof.txt có nội dung:
PROOF-2026

Sau đó đọc lại file.
```

PASS chỉ khi:

```text
write_file success
file exists
read_file returns PROOF-2026
```

---

# 44. GOLDEN E2E TEST 2 — RUN CODE

Prompt:

```text
Tạo hello.py.
Chạy:
python3 hello.py Tấn

Output:
Hello Tấn from ToolNet CLI!
```

PASS:

```text
write
verify
shell
exitCode=0
expected stdout
```

---

# 45. GOLDEN E2E TEST 3 — SELF REPAIR

Prompt:

```text
Tạo bug.py có một lỗi runtime có chủ ý.
Chạy file.
Đọc lỗi.
Sửa lỗi.
Chạy lại.
Chỉ kết thúc khi exit code = 0.
```

Expected lifecycle:

```text
write_file
✓

shell python3 bug.py
✗ exit 1

read_file / edit
✓

shell python3 bug.py
✓ exit 0

final
```

Đây là test quan trọng nhất.

---

# 46. GOLDEN E2E TEST 4 — TEXT-ONLY MUST FAIL

Mock model trả:

```bash
cat > app.py <<'EOF'
print("hello")
EOF
python3 app.py
```

nhưng không trả tool call.

Expected:

```text
successfulMutations = 0
successfulExecutions = 0

CompletionGate = NOT COMPLETE
```

Không được trả success.

---

# 47. GOLDEN E2E TEST 5 — TOOL FAILURE RECOVERY

Tool:

```text
shell("pytest")
```

Result:

```text
exitCode=1
stderr=...
```

Agent phải:

```text
read relevant file
→ edit
→ rerun pytest
```

Không được final sau lần test fail đầu tiên nếu user yêu cầu fix.

---

# 48. GOLDEN E2E TEST 6 — MULTI-FILE PROJECT

Prompt:

```text
Tạo một FastAPI app nhỏ có:
- API
- service layer
- tests
- requirements
- README

Chạy tests.
```

Acceptance:

- multi-file mutation.
- dependency awareness.
- test run.
- repair if failure.
- final diff summary.

---

# 49. GOLDEN E2E TEST 7 — EXISTING REPO FIX

Fixture có bug sẵn.

Prompt:

```text
Tìm nguyên nhân test fail và sửa.
```

Agent phải:

```text
inspect
→ grep
→ read
→ test
→ edit
→ test
```

Không được rewrite toàn project nếu không cần.

---

# 50. GOLDEN E2E TEST 8 — PERMISSION

Prompt yêu cầu lệnh ngoài workspace.

Expected:

```text
permission-required
```

Sau DENY:

```text
tool-error
```

Agent phải thích nghi, không crash CLI.

---

# 51. GOLDEN E2E TEST 9 — CTRL+C

Đang chạy:

```text
shell("sleep 30")
```

Ctrl+C.

Expected:

```text
tool cancelled
process killed
agent turn cancelled
CLI returns prompt
process remains alive
```

---

# 52. GOLDEN E2E TEST 10 — ALIMS-INTL.LLM

Dùng provider ToolNet thật.

Prompt:

```text
Tạo /tmp workspace file hoặc file trong current workspace,
chạy command xác minh,
sửa nếu lỗi.
```

Acceptance:

- model native tool calling hoặc structured fallback phải hoạt động.
- nếu model không thể tool call → CLI báo capability limitation.
- tuyệt đối không fake success.

---

# 53. PERFORMANCE TARGETS

Không đặt latency thấp bằng cách bỏ verification.

Targets:

- startup nhanh.
- TUI responsive.
- streaming không repaint full screen mỗi token.
- tool calls parallel khi độc lập.
- write/edit sequential khi conflict.
- output truncation.
- context compaction.

---

# 54. BACKWARD COMPATIBILITY

Commands cũ:

```text
/provider
/model
/reasoning
/memory
/skills
/tools
/session
```

nên giữ nếu không xung đột core.

Legacy tool aliases có thể map:

```text
bash → shell
run_command → shell
grep_search → grep
glob_search → glob
```

nhưng không expose aliases cho model.

---

# 55. FEATURE FLAGS

Trong migration:

```text
TOOLNET_AGENT_CORE_V2=1
```

Có thể chạy:

```text
legacy
v2
```

trong giai đoạn test.

Tuy nhiên trước release stable phải xóa dual execution path.

Feature flag chỉ dùng migration, không trở thành permanent architecture.

---

# 56. ROLLBACK

Mỗi phase:

- commit riêng.
- test pass trước merge.
- không mix UI redesign vào core rewrite.
- có tag/branch backup.

Ví dụ:

```text
refactor/agent-core-v2
```

Không sửa mascot/theme/layout trong Phase 73.

---

# 57. DEFINITION OF DONE — PHASE 73

Phase 73 chỉ DONE khi tất cả điều sau đúng:

- [ ] Một Shared Agent Engine.
- [ ] Một Tool Registry.
- [ ] Một LLM protocol normalization layer.
- [ ] Một SessionProcessor.
- [ ] TUI không có tool execution loop riêng.
- [ ] Simple REPL và TUI dùng cùng core.
- [ ] Tool lifecycle có call ID.
- [ ] Tool result quay lại model đúng call ID.
- [ ] Native tool calling hoạt động.
- [ ] Structured fallback hoạt động.
- [ ] `alims-intl.llm` có capability behavior rõ.
- [ ] Write/edit có verification thật.
- [ ] Shell trả stdout/stderr/exitCode.
- [ ] Test failure quay lại model để repair.
- [ ] Completion Gate chặn fake success.
- [ ] Ctrl+C không kill CLI.
- [ ] Doom-loop detection.
- [ ] Permission không nằm trong executor UI.
- [ ] Session persistence giữ tool states.
- [ ] Golden E2E tests PASS.
- [ ] Legacy execution paths bị xóa.

---

# 58. KHÔNG LÀM TRONG PHASE 73

Không ưu tiên:

- mascot mới.
- animation.
- theme redesign.
- marketplace.
- nhiều plugin mới.
- agent roles phức tạp.
- background DAG.
- LSP nâng cao.
- browser orchestration nâng cao.

Lý do:

Nếu agent core chưa chắc chắn thì mọi feature mới sẽ xây trên execution path lỗi.

---

# 59. THỨ TỰ TRIỂN KHAI CUỐI CÙNG

```text
P0
Unified contracts

P0
Tool Registry

P0
LLM protocol normalization

P0
Session Processor

P0
Shared Agent Engine

P0
TUI migration

P0
Capability normalization

P0
Snapshot / Verify

P0
Completion Gate

P0
Golden E2E tests

P1
LSP / code intelligence

P1
Subagents

P1
Background / Teamwork

P2
MCP / Plugins / Hooks

P2
Performance / polish
```

---

# 60. QUYẾT ĐỊNH KIẾN TRÚC

ToolNet CLI chính thức theo hướng:

```text
OpenCode-style Core
+
Antigravity-style Shared Agent Architecture
+
ToolNet-specific Provider/Memory/Skills/Teamwork
```

Tỷ trọng tham khảo:

```text
OpenCode technical architecture: ~75%
Antigravity product architecture: ~25%
```

Không copy code nguyên xi.

Mục tiêu là xây ToolNet thành một agent runtime độc lập, có khả năng:

```text
READ
SEARCH
EDIT
WRITE
EXECUTE
OBSERVE
REPAIR
VERIFY
COMPLETE
```

bằng một execution kernel duy nhất.

---

# 61. SUCCESS CRITERION CUỐI

Khi user nhập:

```text
Fix project này cho chạy được.
```

ToolNet phải tự:

```text
detect project
→ inspect files
→ identify commands
→ run tests/build
→ read error
→ search code
→ edit
→ rerun
→ verify
→ repeat until done
→ summarize actual changes
```

Nếu ToolNet chỉ đưa code/prompt/command mà chưa execute, hệ thống phải biết rằng task **chưa hoàn thành**.

Đây là tiêu chuẩn chính để đánh giá Core Rewrite thành công.
